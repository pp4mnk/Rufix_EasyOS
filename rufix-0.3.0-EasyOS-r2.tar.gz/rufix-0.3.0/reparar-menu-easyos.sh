#!/bin/sh
# Restore the EasyOS menu entry without reinstalling Rufix.
set -e
[ "$(id -u)" = 0 ] || { echo "Ejecuta este script como root."; exit 1; }
[ -x /usr/bin/rufix ] && [ -f /usr/lib/rufix/rufix/app.py ] || {
    echo "Rufix no esta instalado en /usr. Ejecuta sh install.sh primero."; exit 1;
}
SRC="$(cd "$(dirname "$0")" && pwd)"
install -D -m 644 "$SRC/data/rufix.desktop" /usr/share/applications/rufix.desktop
install -D -m 644 "$SRC/data/rufix.svg" /usr/share/pixmaps/rufix.svg
ROOT=""
refresh_menu() {
    [ -z "$ROOT" ] || return 0
    if command -v fixmenus >/dev/null 2>&1; then
        if fixmenus; then
            # Reload only an already running JWM session.
            if command -v pidof >/dev/null 2>&1 && pidof jwm >/dev/null 2>&1; then
                jwm -reload || true
            fi
        else
            echo "Aviso: ejecuta fixmenus y reinicia el gestor de ventanas para actualizar el menu."
        fi
    fi
    if command -v update-desktop-database >/dev/null 2>&1; then
        update-desktop-database -q /usr/share/applications || true
    fi
}
refresh_menu
echo "Entrada creada: Menu > Sistema > Rufix. Si no aparece, reinicia el gestor de ventanas."

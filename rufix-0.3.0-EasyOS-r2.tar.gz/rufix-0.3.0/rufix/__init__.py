"""Rufix - a Rufus-style USB formatting and bootable drive creator for Linux."""

__version__ = "0.3.0"
APP_NAME = "Rufix"
APP_ID = "org.rufix.Rufix"
